# This website is created for viewing the movie trailer. It is created using Python. The home page contains a list of movie images with movie title. when the images are clicked it displays the movie trailer that is  associated with the movie image and description.



Steps to run it:

- Download the file
- Open the entertainment_center.py with IDLE
- Run the file
- The browser will open and you could see the web page running on it.
- Click the movie and now the youtube trailer of the respective movie picture will begin to play. 


  